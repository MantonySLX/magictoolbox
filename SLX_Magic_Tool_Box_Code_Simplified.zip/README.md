
# SLX Magic Tool Box

This project contains both the React front-end and Django back-end code.

## How to Run Locally

### React Front-end
1. Navigate to the `React_Frontend` directory.
2. Run `npm install` to install the required packages.
3. Run `npm start` to start the development server.

### Django Back-end
1. Navigate to the `Django_Backend` directory.
2. Run `pip install django` to install Django.
3. Run `python manage.py runserver` to start the development server.

## How to Deploy on Heroku

### React Front-end
1. Create a new Heroku app and connect it to the GitHub repository containing the React code.
2. Enable automatic deploys and deploy the main branch.

### Django Back-end
1. Create a new Heroku app and connect it to the GitHub repository containing the Django code.
2. Enable automatic deploys and deploy the main branch.

For more details, refer to Heroku's documentation.
